FOOD HABITS WEBSITE - GITHUB PAGES

Files:
- index.html: main website page
- style.css: website design and mobile responsive layout
- script.js: mobile menu and nutrition calculator

HOW TO PUBLISH:
1. Create a PUBLIC GitHub repository.
2. Upload these three files directly into the repository root (not inside another folder).
3. Make sure the main file is named exactly index.html (lowercase).
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait a few minutes. Your public link will look like:
   https://YOUR-USERNAME.github.io/REPOSITORY-NAME/

NOTE:
Gallery images load from Unsplash and need an internet connection.
This is a recreated version of the Food Habits project website, not the original Tiiny.host source code.
