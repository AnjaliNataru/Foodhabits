const foods={
 rice:{calories:205,protein:4.3,carbs:44.5,fat:0.4,fibre:0.6},
 idli:{calories:58,protein:2,carbs:12,fat:0.2,fibre:0.5},
 banana:{calories:105,protein:1.3,carbs:27,fat:0.4,fibre:3.1},
 egg:{calories:78,protein:6.3,carbs:0.6,fat:5.3,fibre:0},
 apple:{calories:95,protein:0.5,carbs:25,fat:0.3,fibre:4.4},
 dal:{calories:230,protein:18,carbs:40,fat:0.8,fibre:15},
 milk:{calories:122,protein:8,carbs:12,fat:5,fibre:0}
};
document.getElementById('calculate').addEventListener('click',()=>{
 const key=document.getElementById('food').value;
 const qty=parseFloat(document.getElementById('quantity').value);
 if(!key||!qty||qty<=0){alert('Please select a food and enter a valid quantity.');return;}
 Object.entries(foods[key]).forEach(([name,value])=>{
  document.getElementById(name).textContent=(value*qty).toFixed(1);
 });
});
document.getElementById('menuBtn').addEventListener('click',()=>document.getElementById('nav').classList.toggle('open'));
document.querySelectorAll('#nav a').forEach(a=>a.addEventListener('click',()=>document.getElementById('nav').classList.remove('open')));