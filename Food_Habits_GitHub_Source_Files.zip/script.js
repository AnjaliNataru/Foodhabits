const foods = {
 egg:{name:"Egg",cal:72,protein:6.3,carbs:0.4,fat:4.8,fibre:0},
 milk:{name:"Milk (100 ml)",cal:61,protein:3.2,carbs:4.8,fat:3.3,fibre:0},
 rice:{name:"Cooked rice (100 g)",cal:130,protein:2.7,carbs:28.2,fat:0.3,fibre:0.4},
 banana:{name:"Banana",cal:105,protein:1.3,carbs:27,fat:0.4,fibre:3.1},
 apple:{name:"Apple",cal:95,protein:0.5,carbs:25.1,fat:0.3,fibre:4.4},
 dal:{name:"Cooked dal (100 g)",cal:116,protein:9,carbs:20.1,fat:0.4,fibre:7.9},
 chapati:{name:"Chapati",cal:104,protein:3.1,carbs:18,fat:2.5,fibre:2.7},
 curd:{name:"Curd (100 g)",cal:61,protein:3.5,carbs:4.7,fat:3.3,fibre:0},
 almonds:{name:"Almonds (10 pieces)",cal:70,protein:2.6,carbs:2.6,fat:6.1,fibre:1.5},
 potato:{name:"Boiled potato (100 g)",cal:87,protein:1.9,carbs:20.1,fat:0.1,fibre:1.8}
};
let entries=[];
const $=id=>document.getElementById(id);
const round=n=>Math.round(n*10)/10;
function render(){
 const body=$("items");body.innerHTML="";
 const totals={cal:0,protein:0,carbs:0,fat:0,fibre:0};
 entries.forEach((e,i)=>{
  const f=foods[e.food],q=e.qty;
  ["cal","protein","carbs","fat","fibre"].forEach(k=>totals[k]+=f[k]*q);
  const tr=document.createElement("tr");
  tr.innerHTML=`<td>${f.name}</td><td>${q}</td><td>${round(f.cal*q)}</td><td>${round(f.protein*q)} g</td><td>${round(f.carbs*q)} g</td><td>${round(f.fat*q)} g</td><td>${round(f.fibre*q)} g</td><td><button type="button" data-remove="${i}" aria-label="Remove ${f.name}">Remove</button></td>`;
  body.appendChild(tr);
 });
 $("calories").textContent=`${Math.round(totals.cal)} kcal`;
 $("protein").textContent=`${round(totals.protein)} g`;
 $("carbs").textContent=`${round(totals.carbs)} g`;
 $("fat").textContent=`${round(totals.fat)} g`;
 $("fibre").textContent=`${round(totals.fibre)} g`;
}
$("add").addEventListener("click",()=>{
 const food=$("food").value,qty=Number($("quantity").value);
 if(!Number.isFinite(qty)||qty<=0){$("message").textContent="Please enter a quantity greater than zero.";return;}
 $("message").textContent="";
 entries.push({food,qty});render();
});
$("items").addEventListener("click",e=>{
 const index=e.target.dataset.remove;
 if(index!==undefined){entries.splice(Number(index),1);render();}
});
$("clear").addEventListener("click",()=>{entries=[];$("message").textContent="";render();});
render();